package com.company;

public abstract class Minion {
    private String id;
}
