package com.company;

public interface BirthDayScan {
    public boolean isYearInTarget(String year);
    public String getBirthDate();
}
