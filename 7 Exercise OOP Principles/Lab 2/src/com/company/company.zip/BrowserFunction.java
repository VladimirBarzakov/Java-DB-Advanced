package com.company;

public interface BrowserFunction {
    public void browsing(String[] sites);
}
