package com.company;

public interface CallFunction {
    public void calling(String[] numbers);
}
