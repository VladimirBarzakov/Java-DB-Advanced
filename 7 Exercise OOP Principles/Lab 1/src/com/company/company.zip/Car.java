package com.company;

public interface Car {
    public String getModel();
    public String getDriver();
    public void brakes();
    public void gasPedal();
}
