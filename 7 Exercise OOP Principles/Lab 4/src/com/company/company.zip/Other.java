package com.company;

public class Other extends Animal {
    public Other(String name, Long age, String gender) {
        super(name, age, gender);
    }
}
