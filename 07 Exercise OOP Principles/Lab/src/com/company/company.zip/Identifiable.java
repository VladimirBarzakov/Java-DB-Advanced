package com.company;

public interface Identifiable {
    public String getId();
}
