package com.company;

public interface Birthable {
    public String getBirthDate();
}
